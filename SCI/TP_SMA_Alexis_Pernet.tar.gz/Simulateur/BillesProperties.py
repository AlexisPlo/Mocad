

gridsizeX = 10
gridsizeY = 10
toric = True