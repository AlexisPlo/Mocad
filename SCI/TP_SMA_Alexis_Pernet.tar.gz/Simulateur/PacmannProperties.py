#Proprietes pour l'execution de Wator.py

#Taille de la grille
gridsizeX = 20
gridsizeY = 20

#Nombre de ticks, 0 pour simuler a l'infini
tickNb = 0

#Temps d'attente entre chaque tick, en milli-secondes
tickDuration = 500

hunterNb = 2
powNb = 5